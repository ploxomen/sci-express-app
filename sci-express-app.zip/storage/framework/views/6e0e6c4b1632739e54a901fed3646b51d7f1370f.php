
<?php $__env->startSection('head'); ?>
    <script src="<?php echo e(asset('asset/homedatatable.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/datatable-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/responsive-bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('library/datatable/jq-datatable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/responsive-bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/destinatarios.js')); ?>"></script>
    <title>Mis destinatarios</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<section>
    <div class="bg-white p-2">
        <h3 class="text-primary"><i class="fas fa-caret-right"></i> Mis destinatarios</h3>
        
        <table class="table table-sm table-bordered" id="tabla-destinatario">
            <thead>
                <tr>
                    <th>N°</th>
                    <th>N° Doc.</th>
                    <th>Destinatario</th>
                    <th>Direccion</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="contenido-destinatario"></tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('general.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sci-express-app\resources\views/destinatario/administrador.blade.php ENDPATH**/ ?>