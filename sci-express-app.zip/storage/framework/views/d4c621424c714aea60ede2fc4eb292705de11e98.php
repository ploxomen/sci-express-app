
<?php $__env->startSection('head'); ?>
    <script src="<?php echo e(asset('asset/destinatarioForm.js')); ?>"></script>
    <title><?php echo e($agregar ? 'Agregar destinatario' : 'Editar destinatario'); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<section class="p-2">
    <form id="form-destinatarios" class="row">
        <?php echo csrf_field(); ?>
        <?php if(!$agregar): ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" name="destinatario" value="<?php echo e($destinatario->id); ?>" id="id_nro_doc_cli">
        <?php endif; ?>
        <div class="mb-4 col-12">
            <div class="baner-modulo">
                <img src="<?php echo e(asset('asset/img/intranet/destination.png')); ?>" alt="Imagen de clientes">
            </div>
            <h3 class="text-primary text-center"><?php echo e($agregar ? 'Agregar nuevo destinatario' : 'Modificar destinatario'); ?></h3>
        </div>
        <div class="mb-4 col-12">
            <fieldset class="bg-white px-3 border form-row">
                <legend class="bg-white d-inline-block w-auto px-2 border shadow-sm text-left legend-add text-info">DATOS DEL DESTINATARIO</legend>
                <div class="form-group col-12 col-md-6 col-lg-3">
                    <label for="id_tipo_doc">Tipo documento</label>
                    <select name="tipo_doc" id="id_tipo_doc" class="form-control simple-select2 cb-tipo-doc" data-input="id_nro_doc" required>
                        <option></option>
                        <?php $__currentLoopData = $tipo_documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_docu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tipo_docu->id); ?>" <?php echo e(isset($destinatario->tipo_doc) && $tipo_docu->id === $destinatario->tipo_doc ? 'selected' : ''); ?>><?php echo e($tipo_docu->tipo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-12 col-md-6 col-lg-3">
                    <label for="id_nro_doc">N° documento</label>
                    <input type="text" name="nro_doc" id="id_nro_doc" class="form-control" required value="<?php echo e(isset($destinatario->nro_doc) ? $destinatario->nro_doc : ''); ?>">
                </div>
                <div class="form-group col-12 col-md-6 col-lg-6">
                    <label for="id_nombres">Nombre</label>
                    <input type="text" name="nombres" id="id_nombres" class="form-control" required value="<?php echo e(isset($destinatario->nombres) ? $destinatario->nombres : ''); ?>">
                </div>
            </fieldset>
        </div>
        <div class="mb-4 col-12">
            <fieldset class="bg-white px-3 border form-row">
                <legend class="bg-white d-inline-block w-auto px-2 border shadow-sm text-left legend-add text-info">UBICACION</legend>
                <div class="form-group col-12">
                    <label for="id_direccion">Dirección</label>
                    <input type="text" name="direccion" id="id_direccion" class="form-control" value="<?php echo e(isset($destinatario->direccion) ? $destinatario->direccion : ''); ?>">
                </div>
                <div class="form-group col-12 col-md-6 col-lg-3">
                    <label for="id_dpto_sa">Departamento</label>
                    <select name="departamento" id="id_departamento" class="form-control cb-ubigeo selected-two" data-info="id_provincia" data-consulta="provincia" data-info-distrito="id_distrito" data-info-segundo-distrito="id_ciudad_final">
                        <option value=""></option>
                        <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($departamento->id_ubigeo); ?>" <?php echo e(isset($destinatario->departamento) && $departamento->id_ubigeo == $destinatario->departamento ? 'selected' : ''); ?>><?php echo e($departamento->nombre_ubigeo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-12 col-md-6 col-lg-3">
                    <label for="id_provincia">Provincia</label>
                    <select name="provincia" id="id_provincia" data-info="id_distrito" data-consulta="distrito" class="form-control cb-ubigeo selected-two">
                        <option value=""></option>
                        <?php $__currentLoopData = $provincias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provincia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($provincia->id_ubigeo); ?>" <?php echo e(isset($destinatario->provincia) && $provincia->id_ubigeo == $destinatario->provincia ? 'selected' : ''); ?>><?php echo e($provincia->nombre_ubigeo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-12 col-md-6 col-lg-3">
                    <label for="id_distrito">Distrito</label>
                    <select name="distrito" id="id_distrito" class="form-control cb-ubigeo cb-caserios selected-two" data-ciudades="#id_ciudad_final">
                        <option value=""></option>
                        <?php $__currentLoopData = $distritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($distrito->id_ubigeo); ?>" <?php echo e(isset($destinatario->distrito) && $distrito->id_ubigeo == $destinatario->distrito ? 'selected' : ''); ?>><?php echo e($distrito->nombre_ubigeo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-12 col-md-6 col-lg-3">
                    <label for="id_ciudad_final">Ciudad Final</label>
                    <select name="id_ciudad_final" id="id_ciudad_final" class="form-control simple-select2">
                        <option value=""></option>
                        <?php $__currentLoopData = $caserios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caserio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($caserio->id); ?>" <?php echo e(isset($destinatario->id_ciudad_final) && $caserio->id == $destinatario->id_ciudad_final ? 'selected' : ''); ?>><?php echo e($caserio->nombre_ciudad); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </fieldset>
        </div>
        <div class="form-group col-12">
            <?php if(!$agregar): ?>
                <button type="submit" class="btn btn-primary">Modificar</button>
                <a href="<?php echo e(route('destinatarioMostrar')); ?>" class="btn btn-secondary">Cancelar</a>
            <?php else: ?>
                <button type="submit" class="btn btn-primary">Agregar</button>
                <button type="reset" class="btn btn-secondary">Limpiar</button>
            <?php endif; ?>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('general.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sci-express-app\resources\views/destinatario/crear.blade.php ENDPATH**/ ?>