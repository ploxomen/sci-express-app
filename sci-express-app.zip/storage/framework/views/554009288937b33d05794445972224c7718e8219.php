<section class="row mb-4">
    <div class="form-group col-12 col-lg-4">
        <div class="carta">
            <div class="line bg-primary"></div>
            <div class="principal">
                <span class="tipo">Recojos Hoy</span>
                <span class="valor"><?php echo e($datos['rhoy']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-cash-register material-icons"></i>
            </div>
        </div>
    </div>
    <div class="form-group col-12 col-lg-4">
        <div class="carta">
            <div class="line bg-danger"></div>
            <div class="principal">
                <span class="tipo">Embarques Hoy</span>
                <span class="valor"><?php echo e($datos['ehoy']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-shopping-cart material-icons"></i>
            </div>
        </div>
    </div>
    <div class="form-group col-12 col-lg-4">
        <div class="carta">
            <div class="line bg-warning"></div>
            <div class="principal">
                <span class="tipo">Informes Pendientes</span>
                <span class="valor"><?php echo e($datos['informespendientes']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-users material-icons"></i>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\sci-express-app\resources\views/home/conductordealer.blade.php ENDPATH**/ ?>