
<?php $__env->startSection('head'); ?>
    <script src="<?php echo e(asset('asset/homedatatable.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/datatable-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/responsive-bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('library/datatable/jq-datatable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/responsive-bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/verificacionGuias.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<style>
    .form-editar-guia label {
        font-size: 12px !important;
    }
</style>
<?php $__env->startSection('body'); ?>
    <section class="p-2 bg-white">
        <h3 class="text-primary"><i class="fas fa-caret-right"></i> Verificación</h3>
        <form class="form-row">
            <div class="form-group col-6 col-lg-4 col-xl-2">
                <label for="fecha_inicio">Fecha Inicio</label>
                <input type="date" class="form-control filtro" id="fecha_inicio" value="<?php echo e($fechaFiltros['finFiltro']); ?>" required>
            </div>
            <div class="form-group col-6 col-lg-4 col-xl-2">
                <label for="id_fecha_fin">Fecha Fin</label>
                <input type="date" class="form-control filtro" id="id_fecha_fin" value="<?php echo e($fechaFiltros['inicioFiltro']); ?>" required>
            </div>
        </form>
        <table class="table table-sm table-bordered" id="tabla-guias">
            <thead>
                <tr>
                    <th>N° Guia</th>
                    <th>Fecha Emis</th>
                    <th>Fecha Tras</th>
                    <th>Comprobantes</th>
                    <th>Días Trans</th>
                    <th>Nom Remi</th>
                    <th>Nom Consig</th>
                    <th>Ciudad Base</th>
                    <th>Ciudad Final</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="tabla-detalle-guias"></tbody>
        </table>
    </section>
    <?php echo $__env->make('modal.rechazoGuias', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('general.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sci-express-app\resources\views/comprobante/verificacion.blade.php ENDPATH**/ ?>