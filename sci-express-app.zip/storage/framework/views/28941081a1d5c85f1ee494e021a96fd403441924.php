<div class="modal fade" id="programar-recojo" data-backdrop="static" data-keyboard="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Programar Recojo</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <div class="modal-body">
            <form class="row" id="form-programar-recojo">
                <div class="form-group col-12">
                    <span class="text-info">
                        <b>N° Solicitudes seleccionadas:</b>
                        <b id="modal_nro_solcicitudes"></b>
                    </span>
                </div>
                <div class="form-group col-12 col-md-6">
                    <label for="dia_recojo">Fecha de recojo</label>
                    <input type="date" class="form-control" id="id_dia_recojo" name="dia_recojo" disabled>
                </div>
                <div class="form-group col-12 col-md-6">
                    <label for="id_id_vehiculo">Placa de vehículo</label>
                    <select required class="form-control simple-select2" id="id_id_vehiculo" name="id_vehiculo">
                        <option></option>
                        <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v->id); ?>"><?php echo e($v->placa); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-12" hidden>
                    <label for="id_id_cluster">Cluster Disponibles</label>
                    <select disabled required class="form-control simple-select2" id="id_id_cluster" name="id_cluster">
                        <option></option>
                        <?php $__currentLoopData = $clusters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($v->status === 1): ?>
                                <option value="<?php echo e($v->id_cluster); ?>" data-provincia="<?php echo e($v->provincia_clu); ?>"><?php echo e($v->name); ?> <?php echo e($v->last_name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-12" hidden id="text-info-danger-cluster">
                    <small class="text-danger">No se encontró a ningún cluster para las provincias seleccionadas</small>
                </div>
                <div class="form-group col-12 col-lg-6" hidden>
                    <label for="id_id_conductor">Nombre driver</label>
                        <select disabled required class="form-control simple-select2" id="id_id_conductor" name="id_conductor">
                        <option></option>
                        <?php $__currentLoopData = $conductores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <option <?php echo e($c->status != 1 ? 'disabled' : ''); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?> <?php echo e($c->last_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-12 col-lg-6" hidden>
                    <label for="id_id_dealer">Nombre dealer</label>
                    <select disabled required class="form-control simple-select2" id="id_id_dealer" name="id_dealer">
                        <option></option>
                        <?php $__currentLoopData = $dealers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $de): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e($de->status != 1 ? 'disabled' : ''); ?> value="<?php echo e($de->id); ?>"><?php echo e($de->name); ?> <?php echo e($de->last_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <input type="submit" hidden id="programar-recojo-modal">
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary" id="btn-programar-recojo">Programar</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        </div>
    </div>
  </div>
</div>
<?php /**PATH C:\laragon\www\sci-express-app\resources\views/modal/programarRecojo.blade.php ENDPATH**/ ?>