<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap"
        rel="stylesheet">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('iconos/fontawesome/css/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/general.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/bootstrap/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('library/jquery/external/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('library/bootstrap/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/bootstrap/bootstrap.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('library/select2/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/select2/select2-bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('library/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/select2/es.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('library/alertify/alertify.min.css')); ?>">
    <script src="<?php echo e(asset('library/alertify/alertify.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('library/pagination/pagination.css')); ?>">
    <script src="<?php echo e(asset('library/pagination/pagination.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/general.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/home.js')); ?>"></script>
    <link rel="icon" href="<?php echo e(asset('asset/img/icono.png')); ?>">
    <meta name="theme-color" content="#2e405e">
    <?php echo $__env->yieldContent('head'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body>
    <?php
        $url_actual = Request::url();
    ?>
    <div class="contenedor">
        <div class="navegacion" id="navegacion">
            <div class="mi-logo">
                <img class="d-block img-fluid m-auto" src="<?php echo e(asset('asset/img/favivon.png')); ?>"
                    alt="Icono SCI Express" width="120px">
            </div>
            <ul class="menu accordion" id="accodion-nav">
                <li class="hover-menu <?php echo e($url_actual == route('home') ? 'activeli' : ''); ?>">
                    <a href="<?php echo e(route('home')); ?>" class="menu-prin d-flex gap-1" title="Inicio">
                        <i class="fas fa-home icono"></i>
                        <span class="title">Inicio</span>
                    </a>
                </li>
                <?php $__currentLoopData = $modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($modulo->tipo == 'agrupado'): ?>
                        <?php
                            $modulo->submodulos = json_decode($modulo->submodulos);
                            $active_sub = false;
                            foreach ($modulo->submodulos as $m) {
                                if (route($m->nomRuta) == $url_actual) {
                                    $active_sub = true;
                                    break;
                                }
                            }
                        ?>
                        <li class="menu-desplegable">
                            <a href="#collapse<?php echo e($modulo->grupo); ?>" class="active-panel d-flex gap-1 <?php echo e($active_sub ? 'active-menu' : ''); ?>" title="<?php echo e($modulo->grupo); ?>"
                                data-toggle="collapse" data-target="#collapse<?php echo e($modulo->grupo); ?>">
                                <i class="icono <?php echo e($modulo->icono); ?>"></i>
                                <span class="title"><?php echo e($modulo->grupo); ?></span>
                                <i class="fas fa-angle-down"></i>
                            </a>
                            <ul id="collapse<?php echo e($modulo->grupo); ?>" class="collapse <?php echo e($active_sub ? 'show' : ''); ?>" data-parent="#accodion-nav">
                                <?php $__currentLoopData = $modulo->submodulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submodulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li
                                        class="hover-menu <?php echo e($url_actual == route($submodulo->nomRuta) ? 'activeli' : ''); ?>">
                                        <a href="<?php echo e(route($submodulo->nomRuta)); ?>" class="d-flex gap-1" title="<?php echo e($submodulo->nombre); ?>">
                                            <i class="icono <?php echo e($submodulo->icono); ?>"></i>
                                            <span class="title"><?php echo e($submodulo->nombre); ?></span>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                        </li>
                    <?php else: ?>
                        <li class="hover-menu <?php echo e($url_actual == route($modulo->nomRuta) ? 'activeli' : ''); ?>">
                            <a href="<?php echo e(route($modulo->nomRuta)); ?>" title="<?php echo e($modulo->grupo); ?>">
                                <i class="icono <?php echo e($modulo->icono); ?>"></i>
                                <span class="title"><?php echo e($modulo->grupo); ?></span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li class="hover-menu">
                    <a href="<?php echo e(route('closeSesion')); ?>" class="menu-prin d-flex gap-1" title="Cerrar sesión">
                        <i class="icono fas fa-door-closed"></i>
                        <span class="title">Cerrar sesión</span>
                    </a>
                </li>
            </ul>
        </div>
        <div class="panel">
            <div class="box-serch" hidden>
                <input type="search">
            </div>
            <div class="info-person">
                <div class="btn-menu">
                    <button type="button" id="btn-menu" class="btn-info-menu">
                        <i class="fas fa-bars"></i>
                    </button>
                </div>
                <div class="box-my">
                    <span class="text-primary"><?php echo e(Auth::user()->name); ?></span>
                    <div class="btn-group">
                        <button class="btn-info-menu dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle"></i>
                        </button>
                        <?php
                            if (!isset($_COOKIE['roles'])) {
                                \Auth::logout();
                                \Request::session()->invalidate();
                                \Request::session()->regenerateToken();
                                redirect(route('login'));
                                die();
                            }
                            $roles = json_decode($_COOKIE['roles']);
                        ?>

                        <div class="dropdown-menu dropdown-menu-right">
                            <span class="dropdown-item-text"><span class="text-primary">Área:</span><br><span
                                    id="text_area_index"><?php echo e(empty($roles->area) ? 'No definido' : $roles->area->area); ?></span></span>
                            <div class="dropdown-divider"></div>
                            <h6 class="dropdown-header" id="lista_roles_index">Roles</h6>
                            <?php $__currentLoopData = $roles->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item <?php echo e($rol->active ? 'active' : ''); ?>"
                                    href="<?php echo e(route('cambiarRol', $rol->id)); ?>">
                                    <span><?php echo e($rol->rol); ?></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <h6 class="dropdown-header">Otros</h6>
                            <a class="dropdown-item" href="<?php echo e(route('miPerfil')); ?>"><span>Mi perfil</span></a>
                            <a href="<?php echo e(route('closeSesion')); ?>" class="dropdown-item"><span>Cerrar sesión</span></a>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="cuerpo-panel">
            <?php echo $__env->yieldContent('body'); ?>

        </div>
        <footer class="footer-login">
            <span style="font-size: 0.6rem !important;">Desarrollado por <a href="https://gscreativas.com/"
                    target="_blank">gscreativas.com</a></span>
        </footer>
    </div>
    <div class="content-mi-info" id="contenido-submenu"></div>
</body>

</html>
<?php /**PATH C:\laragon\www\sci-express-app\resources\views/general/index.blade.php ENDPATH**/ ?>