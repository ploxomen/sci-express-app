
<?php $__env->startSection('head'); ?>
    <script src="<?php echo e(asset('asset/homedatatable.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/datatable-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/responsive-bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('library/datatable/jq-datatable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/responsive-bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/auth/misusuarios.js')); ?>"></script>
    <title>Mis usuarios</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<div class="my-4">
    <div class="baner-modulo">
        <img src="<?php echo e(asset('asset/img/intranet/man.png')); ?>" alt="Imagen de clientes">
    </div>
    <h3 class="text-primary text-center">Mis usuario</h3>
</div>
<section class="p-2">
    <div class="bg-white p-3">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-sm" id="tabla-usuarios">
                <thead>
                    <tr>
                        <th>N° Documento</th>
                        <th>Nombres y Apellidos</th>
                        <th>Celular</th>
                        <th>Correo</th>
                        <th>Área</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="lista-usuarios"></tbody>
            </table>
        </div>
    </div>
</section>
<?php echo $__env->make('modal.cambiarpassword', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('modal.editarusuario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('modal.editarroles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('general.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sci-express-app\resources\views/users/lista.blade.php ENDPATH**/ ?>