
<?php $__env->startSection('head'); ?>
    <script src="<?php echo e(asset('asset/homedatatable.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/datatable-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/responsive-bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('library/datatable/jq-datatable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/responsive-bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/missolicitud.js')); ?>"></script>
    <title>Mis solicitudes</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<style>
    .form-info span{
        display: block;
    }
</style>
<section class="p-3 bg-white mb-4">
    <h3 class="text-primary"><i class="fas fa-caret-right"></i> Mis solicitudes</h3>
    <form class="row mb-4" id="filtro-ver-solicitudes">
        <div class="form-group col-12 col-md-6 col-lg-3">
            <label for="filtro_solicitud_inicio">Fecha inicio</label>
            <input type="date" class="form-control" value="<?php echo e($filtros['finFiltro']); ?>" id="filtro_solicitud_inicio">
        </div>
        <div class="form-group col-12 col-md-6 col-lg-3">
            <label for="filtro_solicitud_fin">Fecha fin</label>
            <input type="date" class="form-control" value="<?php echo e($filtros['inicioFiltro']); ?>" id="filtro_solicitud_fin">
        </div>
        <div class="form-group col-12 col-md-6 col-lg-3">
            <label for="estado_soli">Estado</label>
            <select class="form-control cb-filtros" id="estado_soli">
                <option value="" selected>TODOS</option>
                <?php $__currentLoopData = $estados_solicitud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($estado->id); ?>"><?php echo e($estado->estado); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-12 col-md-6 col-lg-3">
            <button type="submit" class="btn btn-sm btn-light mr-1" title="Aplicar los filtros"><i class="fas fa-search"></i></button>
            <button class="btn btn-sm btn-light position-relative mr-1 <?php echo e($confirmacion->count() !== 0 ? 'badge-notification' : ''); ?>" data-info="<?php echo e($confirmacion->count()); ?>" type="button" title="Confirmación nuevas solicitudes" data-toggle="modal" data-target="#modal-notificar-whatsapp" id="btn-notificar-whatsapp"><i class="fab fa-whatsapp"></i></button>
            <button class="btn btn-sm btn-light position-relative <?php echo e($por_procesar !== 0 ? 'badge-notification' : ''); ?>" data-info="<?php echo e($por_procesar); ?>" type="button" title="Asignación masiva" id="btn-asignacion-masiva"><i class="fas fa-globe-asia"></i></button>
        </div>
        <div class="form-group col-12">
            <span class="text-info">Solicitudes pendientes por asignar: <span id="total-por-procesar"><?php echo e($por_procesar); ?></span></span>
        </div>
    </form>
</section>
<section class="p-3 bg-white">
   <table class="table table-sm table-bordered" id="tabla-solicitud">
        <thead>
            <tr>
                <th>N° soli</th>
                <th>N° Recojo</th>
                <th>Fecha Soli</th>
                <th>Día Recojo</th>
                <th>Hr Reco</th>
                <th>N° Doc</th>
                <th>Nom Cliente</th>
                <th>Bulto</th>
                <th>Nom Soli</th>
                <th>Trayecto</th>
                <th>Responsable</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody id="tabla-solicitudes"></tbody>
    </table>
</section>
<?php echo $__env->make('modal.asignarPersonalMasivoSolicitud', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('modal.notificarWhatsappSolicitud', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('modal.editarSolicitud', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('general.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sci-express-app\resources\views/solicitud/mostrar.blade.php ENDPATH**/ ?>