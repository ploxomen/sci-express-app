<section class="row mb-4">
    <div class="col-12">
        <h5 class="text-primary"><i class="fas fa-caret-right"></i> Recojos</h5>
    </div>
    <div class="form-group col-12 col-sm-6 col-lg-4">
        <div class="carta">
            <div class="line bg-info"></div>
            <div class="principal">
                <span class="tipo">Del día</span>
                <span class="valor"><?php echo e($datos['recojodeldia']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-cash-register material-icons"></i>
            </div>
        </div>
    </div>
    <div class="form-group col-12 col-sm-6 col-lg-4">
        <div class="carta">
            <div class="line bg-info"></div>
            <div class="principal">
                <span class="tipo">Programados</span>
                <span class="valor"><?php echo e($datos['recoprogramado']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-money-bill-wave material-icons"></i>
            </div>
        </div>
    </div>
    <div class="form-group col-12 col-sm-6 col-lg-4">
        <div class="carta">
            <div class="line bg-info"></div>
            <div class="principal">
                <span class="tipo">Efectuados</span>
                <span class="valor"><?php echo e($datos['recoefectuado']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-shopping-cart material-icons"></i>
            </div>
        </div>
    </div>
    <div class="col-12">
        <h5 class="text-primary"><i class="fas fa-caret-right"></i> Manifiesto</h5>
    </div>
    <div class="form-group col-12 col-sm-6 col-lg-4">
        <div class="carta">
            <div class="line bg-warning"></div>
            <div class="principal">
                <span class="tipo">Guías por manifestar</span>
                <span class="valor"><?php echo e($datos['manipendienteguia']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-shopping-cart material-icons"></i>
            </div>
        </div>
    </div>
    <div class="form-group col-12 col-sm-6 col-lg-4">
        <div class="carta">
            <div class="line bg-warning"></div>
            <div class="principal">
                <span class="tipo">Guías hoy manifestar</span>
                <span class="valor"><?php echo e($datos['guiahoymanifestar']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-shopping-cart material-icons"></i>
            </div>
        </div>
    </div>
    <div class="form-group col-12 col-sm-6 col-lg-4">
        <div class="carta">
            <div class="line bg-warning"></div>
            <div class="principal">
                <span class="tipo">Embarcar manifiestos</span>
                <span class="valor"><?php echo e($datos['manifiestoembarcar']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-shopping-cart material-icons"></i>
            </div>
        </div>
    </div>
    <div class="col-12">
        <h5 class="text-primary"><i class="fas fa-caret-right"></i> Embarques</h5>
    </div>
    <div class="form-group col-12 col-sm-6 col-lg-4">
        <div class="carta">
            <div class="line bg-danger"></div>
            <div class="principal">
                <span class="tipo">Pendientes</span>
                <span class="valor"><?php echo e($datos['embarquependiente']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-shopping-cart material-icons"></i>
            </div>
        </div>
    </div>
    <div class="form-group col-12 col-sm-6 col-lg-4">
        <div class="carta">
            <div class="line bg-danger"></div>
            <div class="principal">
                <span class="tipo">Efectuados</span>
                <span class="valor"><?php echo e($datos['embarqueefectuados']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-shopping-cart material-icons"></i>
            </div>
        </div>
    </div>
    <div class="form-group col-12 col-sm-6 col-lg-4">
        <div class="carta">
            <div class="line bg-danger"></div>
            <div class="principal">
                <span class="tipo">Por informar</span>
                <span class="valor"><?php echo e($datos['embarqueporinformar']); ?></span>
            </div>
            <div class="icono">
                <i class="fas fa-shopping-cart material-icons"></i>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\laragon\www\sci-express-app\resources\views/home/supervisor.blade.php ENDPATH**/ ?>