
<?php $__env->startSection('head'); ?>
<script src="<?php echo e(asset('asset/entregapedidos.js')); ?>"></script>
<title>Guias para entregar</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<style>
    .card b,
    .card span{
        font-size: 14px;
    }
    .img-guias{
        display: block;
        width: 100%;
        object-fit: contain;
        height: 250px;
    }
    .img-btn-delete{
        width: 30px;
        height: 30px;
        position: absolute;
        top: 0;
        right: 0;
    }
</style>
<section class="p-2">
    <?php if(empty($guias)): ?>
    <div class="form-group">
        <h5 class="text-center text-primary">No se encontraron pedidos para entregar</h5>
    </div>
    <?php else: ?>
    <div class="accordion" id="accordion-guias">
        <?php $__currentLoopData = $guias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-header" id="headingOne<?php echo e($g->id); ?>">
                    <h2 class="mb-0">
                        <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse<?php echo e($g->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($g->id); ?>">
                        <?php if(is_null($g->prefijo)): ?>
                            OS N° <?php echo e($g->nro_guia); ?>

                        <?php else: ?>
                            Guía N° <?php echo e($g->nro_guia); ?>

                        <?php endif; ?>
                        </button>
                    </h2>
                </div>
                <div id="collapse<?php echo e($g->id); ?>" class="collapse <?php echo e($k === 0 ? 'show' : ''); ?>" aria-labelledby="headingOne<?php echo e($g->id); ?>" data-parent="#accordion-guias">
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group col-6">
                                <b>Fecha Emitida: </b>
                                <span><?php echo e($g->format_fecha); ?></span>
                            </div>
                            <div class="form-group col-6">
                                <b>Fecha Reparto: </b>
                                <span><?php echo e($g->fecha_reparto); ?></span>
                            </div>
                            <div class="col-12">
                                <h6 class="text-primary"><i class="fas fa-caret-right"></i> Remitente</h6>
                            </div>
                            <div class="form-group col-12">
                                <b>Nombres: </b>
                                <span><?php echo e($g->nom_prov); ?></span>
                            </div>
                            <div class="col-12">
                                <h6 class="text-primary"><i class="fas fa-caret-right"></i> Destinatario</h6>
                            </div>
                            <div class="form-group col-12">
                                <b>Nombres: </b>
                                <span><?php echo e($g->nom_dest); ?></span>
                            </div>
                            <div class="form-group col-12 col-md-6 col-lg-4">
                                <b>Departamento: </b>
                                <span><?php echo e($g->dest_depa); ?></span>
                            </div>
                            <div class="form-group col-12 col-md-6 col-lg-4">
                                <b>Provincia: </b>
                                <span><?php echo e($g->dest_prov); ?></span>
                            </div>
                            <div class="form-group col-12 col-md-6 col-lg-4">
                                <b>Distrito: </b>
                                <span><?php echo e($g->dest_dist); ?></span>
                            </div>
                            <div class="form-group col-12">
                                <b>Dirección: </b>
                                <span><?php echo e($g->dest_dire); ?></span>
                            </div>
                            <div class="col-12">
                                <h6 class="text-primary"><i class="fas fa-caret-right"></i> Incidencias durante reparto</h6>
                            </div>
                            <div class="form-group col-12 col-md-6">
                                <label for="id_situacion_reparto_<?php echo e($g->id); ?>">Situación Rep</label>
                                <select id="id_situacion_reparto_<?php echo e($g->id); ?>" class="form-control simple-select2 situacion-reparto" data-status="#id_estado_entregado_<?php echo e($g->id); ?>" data-detalle="#id_text_disconforme_reparto_<?php echo e($g->id); ?>" data-incidencia="#id_incidencia_reparto_<?php echo e($g->id); ?>">
                                    <option></option>
                                    <option value="CONFORME" <?php echo e($g->situacion_durante_envio == 'CONFORME' ? 'selected' : ''); ?>>CONFORME</option>
                                    <option value="INCIDENCIA" <?php echo e($g->situacion_durante_envio == 'INCIDENCIA' ? 'selected' : ''); ?>>INCIDENCIA</option>
                                </select>
                            </div>
                            <div class="form-group col-12 col-md-6">
                                <label for="id_incidencia_reparto_<?php echo e($g->id); ?>">Incidencia Rep</label>
                                <select id="id_incidencia_reparto_<?php echo e($g->id); ?>" data-estado="#id_estado_entregado_<?php echo e($g->id); ?>" class="form-control simple-select2 situacion-incidencia" <?php echo e($g->situacion_durante_envio == 'CONFORME' ? 'disabled' : ''); ?>>
                                    <option></option>
                                    <option value="DAÑO PARCIAL" <?php echo e($g->incidencia_durante_envio == "DAÑO PARCIAL" ? 'selected' : ''); ?>>DAÑO PARCIAL</option>
                                    <option value="DAÑO TOTAL" <?php echo e($g->incidencia_durante_envio == "DAÑO TOTAL" ? 'selected' : ''); ?>>DAÑO TOTAL</option>
                                    <option value="PERDIDA PARCIAL" <?php echo e($g->incidencia_durante_envio == "PERDIDA PARCIAL" ? 'selected' : ''); ?>>PERDIDA PARCIAL</option>
                                    <option value="PERDIDA TOTAL" <?php echo e($g->incidencia_durante_envio == "PERDIDA TOTAL" ? 'selected' : ''); ?>>PERDIDA TOTAL</option>
                                </select>
                            </div>
                            <div class="form-group col-12">
                                <textarea class="form-control" <?php echo e($g->situacion_durante_envio == 'CONFORME' ? 'disabled' : ''); ?> id="id_text_disconforme_reparto_<?php echo e($g->id); ?>" placeholder="Detallar la incidencia" maxlength="500"><?php echo e($g->text_durante_disconforme); ?></textarea>
                            </div>
                            <div class="col-12">
                                <h6 class="text-primary"><i class="fas fa-caret-right"></i> Estados de entrega</h6>
                            </div>
                            <div class="form-group col-12 col-md-6 col-lg-4">
                                <label for="id_estado_entregado_<?php echo e($g->id); ?>">Status Ent</label>
                                <select id="id_estado_entregado_<?php echo e($g->id); ?>" class="form-control simple-select2 status-entrega" data-noentregado="#id_motivo_no_ent_<?php echo e($g->id); ?>" data-visitas="#id_nro_visitas_reparto_<?php echo e($g->id); ?>" <?php echo e($g->incidencia_durante_envio == 'DAÑO TOTAL' || $g->incidencia_durante_envio == 'PERDIDA TOTAL' ? 'disabled' : ''); ?>>
                                    <option></option>
                                    <option value="ENTREGADO">ENTREGADO</option>
                                    <option value="NO ENTREGADO">NO ENTREGADO</option>
                                </select>
                            </div>
                            <div class="form-group col-12 col-md-6 col-lg-4">
                                <label for="id_nro_visitas_reparto_<?php echo e($g->id); ?>">N° Visitas</label>
                                <input type="text" class="form-control" id="id_nro_visitas_reparto_<?php echo e($g->id); ?>" value="<?php echo e($g->nro_visitas_reparto == null ? 'PRIMERA' : $g->nro_visitas_reparto); ?>" readonly>
                            </div>
                            <div class="form-group col-12 col-md-6 col-lg-4">
                                <label for="id_motivo_no_ent_<?php echo e($g->id); ?>">Motivo No Ent</label>
                                <select id="id_motivo_no_ent_<?php echo e($g->id); ?>" class="form-control simple-select2" disabled>
                                    <option></option>
                                    <option value="AUSENTE">AUSENTE</option>
                                    <option value="DIR INCOMPLETA">DIR INCOMPLETA</option>
                                    <option value="SE MUDO">SE MUDO</option>
                                    <option value="DESCONOCIDO">DESCONOCIDO</option>
                                    <option value="RECHAZADO">RECHAZADO</option>
                                </select>
                            </div>
                            <div class="form-group col-12">
                                <form id="form-guias-add-<?php echo e($g->id); ?>" hidden enctype="multipart/form-data">
                                    <input type="file" hidden name="img-guias[]" id="img-guias-send-<?php echo e($g->id); ?>" multiple>
                                </form>
                                <input type="file" data-transfer="img-guias-send-<?php echo e($g->id); ?>" hidden id="img-guia-<?php echo e($g->id); ?>" class="imgs-guias" multiple accept="image/*">
                                <button class="btn btn-sm btn-primary btn-add-img" data-input="#img-guia-<?php echo e($g->id); ?>" title="Agregar imágenes"><i class="fas fa-plus"></i> <i class="fas fa-camera"></i></button>
                            </div>
                            <div class="form-group col-12 text-center">
                                <button class="btn btn-sm btn-danger btn-save-entrega" data-nroguia="<?php echo e($g->nro_guia); ?>" data-motivo-noentregado="id_motivo_no_ent_<?php echo e($g->id); ?>" data-nro-visitas="id_nro_visitas_reparto_<?php echo e($g->id); ?>" data-situacion-detalle="id_text_disconforme_reparto_<?php echo e($g->id); ?>" data-situacion-incidencia="id_incidencia_reparto_<?php echo e($g->id); ?>" data-estado-entrega="id_estado_entregado_<?php echo e($g->id); ?>" data-situacion-reparto="id_situacion_reparto_<?php echo e($g->id); ?>" data-guia="<?php echo e($g->id); ?>" data-files="img-guias-send-<?php echo e($g->id); ?>" data-formulario="form-guias-add-<?php echo e($g->id); ?>">Entregar</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('general.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sci-express-app\resources\views/pedidos/entregarguias.blade.php ENDPATH**/ ?>