
<?php $__env->startSection('head'); ?>
    <script src="<?php echo e(asset('asset/homedatatable.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/datatable-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/responsive-bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('library/datatable/jq-datatable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/responsive-bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('asset/miscluster.js')); ?>"></script>
    <title>Mis Clusters</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <section class="p-2 bg-white">
        <h3 class="text-primary"><i class="fas fa-caret-right"></i> Mis Clusters</h3>
        <table id="tabla-cluster" class="table table-sm table-bordered table-striped">
            <thead>
                <tr>
                    <th>N°</th>
                    <th>N° D.N.I</th>
                    <th>Nombres y apellidos</th>
                    <th>N° R.U.C</th>
                    <th>Razón Social</th>
                    <th>Departamento</th>
                    <th>Provincia</th>
                    <th>Ciudad<br>Base</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody id="lista-clusters"></tbody>
        </table>
    </section>
<?php echo $__env->make('modal.editarcluster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('general.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sci-express-app\resources\views/cluster/misclusters.blade.php ENDPATH**/ ?>