
<?php $__env->startSection('head'); ?>
    <script src="<?php echo e(asset('asset/misrecojosretornos.js')); ?>"></script>
    <title>Recoger retornos de clusters</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<style>
    .detalle-otros{
        white-space: pre-line;
        font-size: 13px;
        margin-bottom: 0 !important; 
    }
</style>
<section class="p-2">
   <div class="row">
       <?php if(!empty($programaciones->count())): ?>
            <?php $__currentLoopData = $programaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $total = count($rd->detalles);
                    $semiTotal = 0;
                ?>
                <div class="form-group col-12 col-lg-6">
                    <div class="card">
                        <b class="card-header">N° Recojo - <?php echo e($rd->nroProgramado); ?></b>
                        <div class="card-body">
                            <div class="row">
                                <div class="form-group col-12">
                                    <h6 class="text-primary"><i class="fas fa-caret-right"></i> Responsables</h6>
                                    
                                    <div class="d-flex flex-wrap" style="gap: 0 10px;">
                                        <?php if(!empty($rd->dealers)): ?>
                                        <div>
                                            <b>Dealer:</b>
                                            <span><?php echo e($rd->dealers); ?></span>
                                        </div>
                                        <?php endif; ?>
                                        <?php if(!empty($rd->conductores)): ?>
                                        <div>
                                            <b>Conductor:</b>
                                            <span><?php echo e($rd->conductores); ?></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group col-6">
                                    <b>Fecha Recojo:</b>
                                    <span><?php echo e($rd->fechaProgramada); ?></span>
                                </div>
                                <div class="form-group col-6">
                                    <b>Vehiculo:</b>
                                    <span><?php echo e($rd->vehiculos); ?></span>
                                </div>
                            </div>
                            <div id="accordion_<?php echo e($rd->id); ?>" class="form-group">
                                <?php $__currentLoopData = $rd->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $re): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        if($re->estado >= 3){
                                            $semiTotal++;
                                        }
                                    ?>
                                    <div class="card">
                                        <div class="card-header p-1" id="headingRecojo<?php echo e($re->id); ?>">
                                            <div class="mb-0 d-flex justify-content-between align-items-center">
                                                <button class="btn btn-link" data-toggle="collapse" data-target="#collapseRecojo<?php echo e($re->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                                                    <b><?php echo e($re->empresa); ?></b>
                                                </button>
                                                <b>
                                                    <?php echo e($re->total_bultos); ?>

                                                </b>
                                            </div>
                                        </div>
                                        <div id="collapseRecojo<?php echo e($re->id); ?>" class="collapse <?php echo e($key === 0 ? 'show' : ''); ?>" aria-labelledby="headingRecojo<?php echo e($re->id); ?>" data-parent="#accordion_<?php echo e($rd->id); ?>">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="form-group col-12">
                                                        <b>Empresa Transporte: </b>
                                                        <span><?php echo e($re->empresa); ?></span>
                                                    </div>
                                                    <div class="form-group col-12 col-md-7">
                                                        <b>Cluster: </b>
                                                        <span><?php echo e($re->nombreCluster); ?></span>
                                                    </div>
                                                    <div class="form-group col-12 col-md-5">
                                                        <b>FechaHr Llegada: </b>
                                                        <span><?php echo e($re->fechaHrLlegada); ?></span>
                                                    </div>
                                                    <div class="form-group col-4 col-md-3">
                                                        <b>Sobres:</b>
                                                        <span><?php echo e(empty($re->nro_sobres) ? 0 : $re->nro_sobres); ?></span>
                                                    </div>
                                                    <div class="form-group col-4 col-md-3">
                                                        <b>Paquetes:</b>
                                                        <span><?php echo e(empty($re->nro_paquetes) ? 0 : $re->nro_paquetes); ?></span>
                                                    </div>
                                                    <div class="form-group col-4 col-md-3">
                                                        <b>Cajas:</b>
                                                        <span><?php echo e(empty($re->nro_cajas) ? 0 : $re->nro_cajas); ?></span>
                                                    </div>
                                                    <div class="form-group col-4 col-md-3">
                                                        <b>Jabas:</b>
                                                        <span><?php echo e(empty($re->nro_jabas) ? 0 : $re->nro_jabas); ?></span>
                                                    </div>
                                                    <div class="form-group col-4 col-md-3">
                                                        <b>Cajones:</b>
                                                        <span><?php echo e(empty($re->nro_cajones) ? 0 : $re->nro_cajones); ?></span>
                                                    </div>
                                                    <div class="form-group col-4 col-md-3">
                                                        <b>Otros:</b>
                                                        <span><?php echo e(empty($re->num_otros) ? 0 : $re->num_otros); ?></span>
                                                    </div>
                                                    <div class="form-group col-12">
                                                        <b>Detalle Otros:</b>
                                                        <p class="detalle-otros"><?php echo e(empty($re->detalle_otro) ? "-" : $re->detalle_otro); ?></p>
                                                    </div>
                                                    <div class="form-group col-12">
                                                        <b>Tipo Comprobantes: </b>
                                                        <span><?php echo e(empty($re->tipo_comprobantes) ? "-" : $re->tipo_comprobantes); ?></span>
                                                    </div>
                                                    <div class="form-group col-12">
                                                        <b>N° Comprobantes: </b>
                                                        <span><?php echo e(empty($re->nro_guias) ? "-" : $re->nro_guias); ?></span>
                                                    </div>
                                                    <div class="form-group col-12">
                                                        <b>Importe Embarque: </b>
                                                        <span><?php echo e(empty($re->importe_embarque) ? "S/ 0.00" : "S/ " . $re->importe_embarque); ?></span>
                                                    </div>
                                                    <div class="form-group col-12 text-center">
                                                    <?php if($re->estado === 2): ?>
                                                        <button class="btn btn-sm btn-outline-success btn-recoger" data-cluster="<?php echo e($re->nombreCluster); ?>" data-fecha="<?php echo e($re->fechaHrLlegada); ?>" data-recogo="<?php echo e($rd->id); ?>" data-retorno="<?php echo e($re->id); ?>">
                                                            Recogido
                                                        </button>
                                                    <?php else: ?>
                                                        <b>Fecha Hr. Recogido: </b>
                                                        <span><?php echo e(empty($re->fechaHrRecogido) ? "-" : $re->fechaHrRecogido); ?></span>
                                                    <?php endif; ?>
                                                    </div>
                                                </div>                                                
                                            </div>
                                        </div>
                                    </div>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php if($total === $semiTotal): ?>
                                <div class="form-group text-center">
                                    <button class="btn btn-sm btn-outline-primary btn-finalizar" data-recogo="<?php echo e($rd->id); ?>">
                                        Finalizar Recojo
                                    </button>
                                </div>
                                
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php else: ?>
           <div class="form-group col-12 bg-white p-2">
               <h3 class="text-primary text-center">No se encontraron recojos pendientes</h3>
           </div>
       <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('general.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sci-express-app\resources\views/retornos/recojerProgramacion.blade.php ENDPATH**/ ?>