
<?php $__env->startSection('head'); ?>
   
    <script src="<?php echo e(asset('asset/recojos.js')); ?>"></script>
    <title>Recojos</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<section class="p-2">
    <div class="my-4">
        <div class="baner-modulo">
            <img src="<?php echo e(asset('asset/img/intranet/pickup.png')); ?>" alt="Imagen de clientes">
        </div>
        <h3 class="text-primary text-center">Recojos</h3>
    </div>
    <div class="mb-4 bg-white p-3">
        <div class="row">
            <div class="col-12 col-md-6 col-lg-8">
                <h4 class="text-primary">Solicitud de recojos</h4>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
                <form id="frm_filtros_soli" class="form-row">
                    <div class="form-group col-6">
                        <label for="filtro_fecha_recojo">Fecha Recojo</label>
                        <input type="date" value="<?php echo e(date('Y-m-d')); ?>" class="form-control form-control-sm" id="filtro_fecha_recojo">
                    </div>
                    <div class="form-group col-6">
                        <label for="filtro_id_trayecto">Trayectos</label>
                        <select name="trayecto" required id="filtro_id_trayecto" class="form-control form-control-sm">
                            <option value="0">Todos</option>
                            <?php $__currentLoopData = $trayectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trayecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($trayecto->id); ?>"><?php echo e($trayecto->tipo); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </form>
            </div>
        </div>
        <div class="form-group">
            <div class="for-group">
                <h6 class="text-primary d-inline-block">Total Solicitud por programar:</h6>
                <h6 class="d-inline-block" id="total_solicitudes_mostradas_programar"></h6>
            </div>
            <div class="form-group">
                <h6 class="text-primary d-inline-block">N° de Solicitudes mostradas:</h6>
                <h6 class="d-inline-block" id="total_solicitudes_mostradas"></h6>
            </div>
        </div>
        <div class="form-group">
            <h6 class="text-primary">Solicitudes agrupadas por Fch. Recojo:</h6>
            <div class="d-flex flex-wrap" style="gap: 10px;" id="id_fechas_recojos_solicitud"></div>
        </div>
        <div class="d-flex mb-3" style="gap: 10px;">
            <div>
                <div class="cuadro table-success"></div>
                <span>Asignados</span>
            </div>
            <div>
                <div class="cuadro table-warning"></div>
                <span>Sin asignar</span>
            </div>
            <div>
                <div class="cuadro table-info"></div>
                <span>Por reprogramar</span>
            </div>
        </div>
        <div class="form-group table-responsive">
            <table class="table table-bordered table-striped table-sm" id="tabla-solicitud">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="seleccionar_todo"></th>
                        <th>N° Soli</th>
                        <th>Fch. Hr. <br>Recojo</th>
                        <th>N° Doc Cli</th>
                        <th>Nomb Cliente</th>
                        <th>Nomb Soli</th>
                        <th>Trayecto</th>
                        <th>Departamento</th>
                        <th>Provincia</th>
                        <th>Distrito</th>
                        <th>Dirección</th>
                        <th>Bulto</th>
                    </tr>
                </thead>
                <tbody id="tabla-cuerpo-soli"></tbody>
            </table>
        </div>
        <div class="form-group">
            <button type="button" class="btn btn-success btn-sm" id="siguiente_programar"><i class="fas fa-hand-point-right"></i> Siguiente</button>
        </div>
    </div>
    
        
</section>
<?php echo $__env->make('modal.programarRecojo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('general.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sci-express-app\resources\views/pedidos/recojos.blade.php ENDPATH**/ ?>