
<?php $__env->startSection('head'); ?>
    <script src="<?php echo e(asset('asset/homedatatable.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/datatable-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/datatable/responsive-bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('library/datatable/jq-datatable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/datatable-responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('library/datatable/responsive-bootstrap.min.js')); ?>"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/nanogallery2/3.0.5/css/nanogallery2.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/nanogallery2/3.0.5/jquery.nanogallery2.min.js"></script>
    <script src="<?php echo e(asset('asset/misguias.js')); ?>"></script>
    <title>Mis guías</title>
<?php $__env->stopSection(); ?>
<style>
    .form-editar-guia label{
        font-size: 12px !important;
    }
</style>
<?php $__env->startSection('body'); ?>
<section class="p-2 bg-white">
    <h3 class="text-primary"><i class="fas fa-caret-right"></i> Mis guias</h3>
    <form class="form-row" id="frm-aplicar-filtros">
        <div class="form-group col-6 col-lg-4 col-xl-2">
            <label for="fecha_inicio">Fecha Inicio</label>
            <input type="date" class="form-control" id="fecha_inicio" value="<?php echo e($fechaFiltros['finFiltro']); ?>" required>
        </div>
        <div class="form-group col-6 col-lg-4 col-xl-2">
            <label for="id_fecha_fin">Fecha Fin</label>
            <input type="date" class="form-control" id="id_fecha_fin" value="<?php echo e($fechaFiltros['inicioFiltro']); ?>" required>
        </div>
        <div class="form-group col-12 col-md-6 col-lg-4">
            <label for="estado_guias">Status</label>
            <select class="form-control cb-filtros" id="estado_guias">
                <option value="0" selected>TODOS</option>
                <?php $__currentLoopData = $estado_guias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($estado->id); ?>"><?php echo e($estado->tipo); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-12 col-md-6 col-lg-4 col-xl-2">
            <label for="id_tipo">Tipo</label>
            <select class="form-control cb-filtros" id="id_tipo">
                <option value="0" selected>TODOS</option>
                <option value="1">ACTIVA</option>
                <option value="2">ANULADA</option>
                <option value="3">INACTIVA</option>
            </select>
        </div>
        <div class="form-group col-12 col-md-6 col-lg-4 col-xl-2">
            <button type="submit" class="btn btn-sm btn-light" title="Aplicar los filtros"><i class="fas fa-search"></i></button>
            <button type="button" class="btn btn-sm btn-light" title="Asignación masiva" id="view-lista-guias"><i class="fas fa-globe-asia"></i></button>
            <div class="btn-group">
                <button class="btn btn-sm btn-outline-info dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                    <i class="far fa-folder"></i> Reportes
                </button>
                <div class="dropdown-menu">
                <a class="dropdown-item reporte-general" data-tipo="excel" href="#"><i class="far fa-file-excel text-success"></i> Excel</a>
                <a class="dropdown-item reporte-general" data-tipo="pdf" href="#"><i class="far fa-file-pdf text-danger"></i> PDF</a>
                </div>
            </div>
        </div>
        <div class="form-group col-12">
            <span class="text-info">Total N° Guías/OS sin asignar: <span id="total-por-procesar-guias"><?php echo e($nro_por_asignar[0]->total); ?></span></span>
        </div>
    </form>
    <div class="form-group">
        <div class="cuadro table-warning"></div>
        <span>Por asignar</span>
    </div>
   <table class="table table-sm table-bordered" id="tabla-guias">
        <thead>
            <tr>
                <th>N° Guia</th>
                <th>Fecha Emis</th>
                <th>Fecha Tras</th>
                <th>Comprobantes</th>
                <th>Días Trans</th>
                <th>Nom Remi</th>
                <th>Nom Consig</th>
                <th>Ciudad Base</th>
                <th>Ciudad Final</th>
                <th>Clusters</th>
                <th>Resp Embar</th>
                <th>Estado</th>
                <th>Tipo</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody id="tabla-detalle-guias">
            <tr>
                <td colspan="100%" class="text-center">Sin resultados</td>
            </tr>
        </tbody>
    </table>
</section>
<?php echo $__env->make('modal.detalleguiatodos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('modal.editarguia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('modal.asignarPersonalMasivoGuia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('general.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sci-express-app\resources\views/comprobante/misguias.blade.php ENDPATH**/ ?>