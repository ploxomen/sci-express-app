
<?php $__env->startSection('head'); ?>
    <title>Inicio</title>
    <?php if($rol_user->id_rol == 1): ?>
        <script src="<?php echo e(asset('asset/home/manager.js')); ?>"></script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <style>
        .carta{
            position: relative;
            background: var(--color-secundario);
            padding: 20px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            overflow: hidden;
        }
        .carta .line{
            width: 6px;
            height: 100%;
            position: absolute;
            left: 0;
        }
        .carta .principal .tipo{
            font-size: 15px;
            display: block;
            margin-bottom: 5px;
        }
        .carta .icono .material-icons{
            color: #3F80EA;
            background: #E0EAFC;
            padding: 10px;
            border-radius: 50%;
        }
        .carta .principal .valor{
            color: var(--color-letra-title);
        }
        .graficos{
            width: 100%;
            min-height: 350px !important;
        }
    </style>
    <h5>Panel de inicio</h5>
    <div class="p-3">
        <?php switch($rol_user->id_rol):
            case (1): ?>
                <?php echo $__env->make('home.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
            <?php case (2): ?>
                <?php echo $__env->make('home.supervisor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
            <?php case (3): ?>
                <?php echo $__env->make('home.digitador', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
            <?php case (4): ?>
                <?php echo $__env->make('home.boss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
            <?php case (5): ?>
                <?php echo $__env->make('home.sectorista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
            <?php case (6): ?>
                <?php echo $__env->make('home.conductordealer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
            <?php case (7): ?>
                <?php echo $__env->make('home.conductordealer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
            <?php case (8): ?>
                <?php echo $__env->make('home.cluster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
            <?php default: ?>
                <?php echo $__env->make('home.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endswitch; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('general.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sci-express-app\resources\views/users/home.blade.php ENDPATH**/ ?>