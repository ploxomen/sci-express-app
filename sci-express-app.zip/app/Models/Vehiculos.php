<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vehiculos extends Model
{
    protected $table = 'vehiculos';
    public $timestamps = false;
    
    public static function obtenerVehiculos()
    {
        return Vehiculos::where(['activo' => 1])->orderBy('placa')->get();
    }
}
